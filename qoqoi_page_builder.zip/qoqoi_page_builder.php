<?php
/*
Plugin Name: Qoqoi Auto Page Builder
Plugin URI: http://qoqoi.com
Description: Automatically generates pages with customizable content using shortcodes.
Version: 1.0
Author: Ronik Rawat
Author URI: http://qoqoi.com
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: qoqoi-auto-page-builder
*/
// Define the shortcode for the disclaimer page
add_shortcode('disclaimer', 'my_disclaimer_shortcode');

function my_disclaimer_shortcode() {
	// Get the site name and URL
	$site_name = get_bloginfo('name');
	$site_url = get_bloginfo('url');
	
	// Create the disclaimer content
	$disclaimer_content = "Welcome to $site_name! Please read the following disclaimer carefully before using our website. \n\n";
	$disclaimer_content .= "The information provided on this website is for general informational purposes only. We make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose. \n\n";
	$disclaimer_content .= "Any reliance you place on such information is therefore strictly at your own risk. In no event will we be liable for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this website. \n\n";
	$disclaimer_content .= "Through this website you are able to link to other websites which are not under our control. We have no control over the nature, content and availability of those sites. The inclusion of any links does not necessarily imply a recommendation or endorse the views expressed within them. \n\n";
	$disclaimer_content .= "Every effort is made to keep the website up and running smoothly. However, we take no responsibility for, and will not be liable for, the website being temporarily unavailable due to technical issues beyond our control. \n\n";
	$disclaimer_content .= "By using our website, you accept this disclaimer in full. If you disagree with any part of this disclaimer, please do not use our website.";
	
	// Generate the disclaimer section HTML
	$disclaimer_html = '<div class="disclaimer">';
	$disclaimer_html .= '<p>' . esc_html($disclaimer_content) . '</p>';
	$disclaimer_html .= '</div>';
	
	return $disclaimer_html;
}

// Define the shortcode for the about us section
add_shortcode('my_about_us', 'my_about_us_shortcode');

function my_about_us_shortcode() {
  // Get the site name and URL
  $site_name = get_bloginfo('name');
  $site_url = get_bloginfo('url');

  // Create the about content
  $about_content = "Hi, I'm the owner of $site_name. Welcome to my website! Here's a little bit about me: \n\n";
  $about_content .= "I'm passionate about Blogging and have been working in this field for 4 years. \n\n";
  $about_content .= "I started this website to share my views and the updates with the people with common intrest. \n\n";
  $about_content .= "On our site $site_name, you will find all genuine information which has been taken from experience, practiced by doing research on the internet.. \n\n";
  $about_content .= "If you have any questions or comments, please don't hesitate to contact me. Thanks for visiting ";

  // Generate the about us section HTML
  $about_html = '<div class="about-us">';
  $about_html .= '<p>' . esc_html($about_content) . '<a href="$site_url">$site_url</a> !</p>';
  $about_html .= '</div>';

  return $about_html;
}

// Define the shortcode for the contact form
add_shortcode('my_contact_us', 'my_contact_form_shortcode');

function my_contact_form_shortcode() {
  // Get the site name and URL
  $site_name = get_bloginfo('name');
  $site_url = get_bloginfo('url');

  // Create the contact content
  $contact_content = "Thanks for visiting $site_name! If you have any questions or comments, please don't hesitate to contact us. \n\n";
  $contact_content .= "You can reach us by emailing us or by using the form below. We'll get back to you as soon as possible. \n\n";
  $contact_content .= "Thanks again for visiting $site_name!";

  // Generate the HTML form with pre-filled values
  $form_html = '<div class="contact-form">';
  $form_html .= '<p>' . esc_html($contact_content) . '</p>';
  $form_html .= '<form method="post" action="send-email.php">';
  $form_html .= '<label for="name">Your Name:</label>';
  $form_html .= '<input type="text" id="name" name="name" value="' . esc_attr(get_the_author_meta(' ')) . '"><br>';
  $form_html .= '<label for="email">Your Email:</label>';
  $form_html .= '<input type="email" id="email" name="email" value="' . esc_attr(get_the_author_meta('user_email')) . '"><br>';
  $form_html .= '<label for="subject">Subject:</label>';
  $form_html .= '<input type="text" id="subject" name="subject" value="">' .
  '<br>';
  $form_html .= '<label for="message">Message:</label>';
  $form_html .= '<textarea id="message" name="message"></textarea><br>';
  $form_html .= '<input type="submit" value="Submit">';
  $form_html .= '</form>';
  $form_html .= '</div>';
  
  return $form_html;
  }

  // Define the shortcode for the privacy policy
add_shortcode('my_privacy', 'my_privacy_policy_shortcode');

  function my_privacy_policy_shortcode() {
	// Get the site name and URL
	$site_name = get_bloginfo('name');
	$site_url = get_bloginfo('url');
	
	// Create the privacy policy content
	$privacy_policy_content = "Thank you for visiting $site_name! We take your privacy seriously and want to be transparent about how we collect, use, and share your information. \n\n";
	$privacy_policy_content .= "We may collect personal information from you such as your name and email address when you subscribe to our newsletter or fill out a contact form. This information will only be used to send you updates about our website or to respond to your inquiries. \n\n";
	$privacy_policy_content .= "We also use cookies to improve your browsing experience on our website. Cookies are small files that are placed on your device to help us analyze how you use our website and to provide personalized content and advertisements. You can choose to accept or decline cookies in your browser settings. \n\n";
	$privacy_policy_content .= "We do not sell or share your personal information with third-party advertisers or marketers. However, we may share your information with service providers who help us operate our website, such as hosting and email providers. These providers are required to maintain the confidentiality and security of your information. \n\n";
	$privacy_policy_content .= "If you have any questions or concerns about our privacy policy, please contact us at our email. \n\n";
	$privacy_policy_content .= "Thanks again for visiting $site_name!";
	
	// Generate the HTML for the privacy policy section
	$privacy_policy_html = '<div class="privacy-policy">';
	$privacy_policy_html .= '<p>' . esc_html($privacy_policy_content) . '</p>';
	$privacy_policy_html .= '</div>';
	
	return $privacy_policy_html;
	}

	// Define the shortcode for the terms and conditions page
add_shortcode('my_terms', 'my_terms_conditions_shortcode');

function my_terms_conditions_shortcode() {
	// Get the site name and URL
	$site_name = get_bloginfo('name');
	$site_url = get_bloginfo('url');
  
	// Create the terms and conditions content
	$terms_content = "Welcome to $site_name! Please read these terms and conditions carefully before using our website. \n\n";
	$terms_content .= "By using our website, you agree to be bound by these terms and conditions. If you do not agree to these terms and conditions, please do not use our website. \n\n";
	$terms_content .= "The information on this website is provided 'as is' and we make no warranties, expressed or implied, and hereby disclaim and negate all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights. \n\n";
	$terms_content .= "We do not guarantee the accuracy or completeness of any information on our website and are not responsible for any errors or omissions or for the results obtained from the use of such information. \n\n";
	$terms_content .= "In no event shall $site_name or its affiliates be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on our website. \n\n";
	$terms_content .= "We reserve the right to modify these terms and conditions at any time without notice. By using our website you are agreeing to be bound by the then current version of these terms and conditions. \n\n";
	$terms_content .= "If you have any questions or comments, please contact us at [your email address]. Thanks for visiting $site_url!";
  
	// Generate the terms and conditions section HTML
	$terms_html = '<div class="terms-conditions">';
	$terms_html .= '<p>' . esc_html($terms_content) . '</p>';
	$terms_html .= '</div>';
  
	return $terms_html;
  }


// Define a function to automatically create the pages
function my_auto_page_builder() {
	// Check if the pages have already been created
    $about_us_page = get_page_by_title('About Us');
	$contact_us_page = get_page_by_title('Contact Us');
	$terms_page = get_page_by_title('Terms and Conditions');
	$privacy_page = get_page_by_title('Privacy Policy');
	$disclaimer_page = get_page_by_title('Disclaimer');
	
	if (!$disclaimer_page) {
		$disclaimer = array(
			'post_title' => 'Disclaimer',
			'post_content' => '[disclaimer]',
			'post_status' => 'publish',
			'post_type' => 'page'
		);
		$result = wp_insert_post($disclaimer);
		
		if ($result != 0) {
			error_log('Disclaimer page created successfully');
		} else {
			error_log('Error creating disclaimer page');
		}
	}

    // If the pages don't exist, create them
	if (!$about_us_page) {
        $about_us = array(
        'post_title' => 'About Us',
        'post_content' => '[my_about_us]',
        'post_status' => 'publish',
        'post_type' => 'page'
        );
        $result = wp_insert_post($about_us);
		
		if ($result != 0) {
			error_log('Disclaimer page created successfully');
		} else {
			error_log('Error creating disclaimer page');
		}
    }
        
        if (!$contact_us_page) {
        $contact_us = array(
        'post_title' => 'Contact Us',
        'post_content' => '[my_contact_us]',
        'post_status' => 'publish',
        'post_type' => 'page'
        );
        $result = wp_insert_post($contact_us);
        
        if ($result != 0) {
			error_log('Disclaimer page created successfully');
		} else {
			error_log('Error creating disclaimer page');
		}
    }
        
        if (!$terms_page) {
        $terms = array(
        'post_title' => 'Terms and Conditions',
        'post_content' => '[my_terms]',
        'post_status' => 'publish',
        'post_type' => 'page'
        );
        $result = wp_insert_post($terms);
        if ($result != 0) {
			error_log('Disclaimer page created successfully');
		} else {
			error_log('Error creating disclaimer page');
		}    
    }
        
        if (!$privacy_page) {
        $privacy = array(
        'post_title' => 'Privacy Policy',
        'post_content' => '[my_privacy]',
        'post_status' => 'publish',
        'post_type' => 'page'
        );
        $result = wp_insert_post($privacy);
        if ($result != 0) {
			error_log('Disclaimer page created successfully');
		} else {
			error_log('Error creating disclaimer page');
		}
    }
}

// Create the pages when the plugin is activated
register_activation_hook(__FILE__, 'my_auto_page_builder');
?>
